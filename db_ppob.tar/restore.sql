--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP TABLE public.tb_tarif;
DROP TABLE public.tb_tagihan;
DROP TABLE public.tb_penggunaan;
DROP TABLE public.tb_pembayaran;
DROP TABLE public.tb_pelanggan;
DROP TABLE public.tb_level;
DROP TABLE public.tb_admin;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_admin (
    id_admin character varying(10),
    username character varying(30),
    password character varying(30),
    nama_admin character varying(20),
    id_level character varying(10)
);


ALTER TABLE tb_admin OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level character varying(10),
    nama_level character varying(20)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pelanggan (
    id_pelanggan character varying(10),
    username character varying(30),
    password character varying(30),
    no_kwh character varying(15),
    nama_pelanggan character varying(20),
    alamat text,
    id_tarif character varying(10)
);


ALTER TABLE tb_pelanggan OWNER TO postgres;

--
-- Name: tb_pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pembayaran (
    id_pembayaran character varying(10),
    id_pelanggan character varying(10),
    tgl_pembayaran date,
    bulan_bayar character varying(10),
    biaya_admin integer,
    total_bayar integer,
    id_admin character varying(10)
);


ALTER TABLE tb_pembayaran OWNER TO postgres;

--
-- Name: tb_penggunaan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_penggunaan (
    id_penggunaan character varying(10),
    id_pelanggan character varying(10),
    bulan character varying(10),
    tahun character varying(5),
    meter_awal integer,
    meter_akhir integer
);


ALTER TABLE tb_penggunaan OWNER TO postgres;

--
-- Name: tb_tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_tagihan (
    id_tagihan character varying(10),
    id_pengguna character varying(10),
    id_pelanggan character varying(10),
    bulan character varying(10),
    tahun character varying(5),
    jumlah_meter integer,
    status character varying(10)
);


ALTER TABLE tb_tagihan OWNER TO postgres;

--
-- Name: tb_tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_tarif (
    id_tarif character varying(10),
    daya integer,
    tarifperkwh integer
);


ALTER TABLE tb_tarif OWNER TO postgres;

--
-- Data for Name: tb_admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM stdin;
\.
COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM '$$PATH$$/2819.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2820.dat';

--
-- Data for Name: tb_pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pelanggan (id_pelanggan, username, password, no_kwh, nama_pelanggan, alamat, id_tarif) FROM stdin;
\.
COPY tb_pelanggan (id_pelanggan, username, password, no_kwh, nama_pelanggan, alamat, id_tarif) FROM '$$PATH$$/2815.dat';

--
-- Data for Name: tb_pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pembayaran (id_pembayaran, id_pelanggan, tgl_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM stdin;
\.
COPY tb_pembayaran (id_pembayaran, id_pelanggan, tgl_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM '$$PATH$$/2818.dat';

--
-- Data for Name: tb_penggunaan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM stdin;
\.
COPY tb_penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM '$$PATH$$/2814.dat';

--
-- Data for Name: tb_tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_tagihan (id_tagihan, id_pengguna, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tb_tagihan (id_tagihan, id_pengguna, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM '$$PATH$$/2816.dat';

--
-- Data for Name: tb_tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_tarif (id_tarif, daya, tarifperkwh) FROM stdin;
\.
COPY tb_tarif (id_tarif, daya, tarifperkwh) FROM '$$PATH$$/2817.dat';

--
-- PostgreSQL database dump complete
--

